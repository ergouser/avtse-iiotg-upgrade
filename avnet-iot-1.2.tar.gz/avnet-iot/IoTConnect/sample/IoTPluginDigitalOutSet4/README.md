# Smartedge Set Digital Output 4

This command sets the Smartedge digital output 4


## Versioning

This is version 1.0 of the Python Plugin for DigitalOutSet4

## License

This project is licensed under the SmartEdge IIOT Gateway license.

