# Avnet Smartedge Gateway Cpu Frequency

Report CPU frequency

## Installation

Selected with IoTConnectSDKConfigure tool

## Versioning

This is version 1.0 of the Avnet Smartedge Gateway Cpu Frequency Plugin.

## License

This project is licensed under the SmartEdge IIOT Gateway license.

