# Smartedge Clear Digital Output 2

This command clears the Smartedge digital output 2


## Versioning

This is version 1.0 of the Python Plugin for DigitalOutClear2

## License

This project is licensed under the SmartEdge IIOT Gateway license.

