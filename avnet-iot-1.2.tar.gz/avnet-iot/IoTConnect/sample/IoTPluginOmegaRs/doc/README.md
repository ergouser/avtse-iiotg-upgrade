# Omega RS485 Smart Sensor


Please see documentation here.

TBD

## Installation

Please see documentation here.

TBD

## Versioning

This is version 1.0 of the Omega RS485 Smart Sensor Plugin.

## License

This project is licensed under the SmartEdge IIOT Gateway license.

