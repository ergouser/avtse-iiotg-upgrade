# Avnet Smartedge Gateway DigitalIn1

Report Gateway DigitalIn1

## Installation

Selected with IoTConnectSDKConfigure tool

## Versioning

This is version 1.0 of the Avnet Smartedge Gateway DigitalIn1 Plugin.

## License

This project is licensed under the SmartEdge IIOT Gateway license.

