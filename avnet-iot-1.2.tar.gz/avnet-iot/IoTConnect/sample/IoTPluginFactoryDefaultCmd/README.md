# Smartedge Factory Reset

This command Factory Resets the Smartedge Gateway.


## Versioning

This is version 1.0 of the Python Plugin for FactoryReset

## License

This project is licensed under the SmartEdge IIOT Gateway license.

