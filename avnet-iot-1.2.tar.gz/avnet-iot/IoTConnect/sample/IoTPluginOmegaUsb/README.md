# Omega IF-001 USB Smart Sensor


Please see documentation here.

https://www.newark.com/omega/if-001-0/smart-probe-usb-interface-m12/dp/51AH5793

## Installation

Please see documentation here.

http://www.farnell.com/datasheets/2892192.pdf

## Versioning

This is version 1.0 of the Omega Usb Smart Sensor Plugin.

## License

This project is licensed under the SmartEdge IIOT Gateway license.

