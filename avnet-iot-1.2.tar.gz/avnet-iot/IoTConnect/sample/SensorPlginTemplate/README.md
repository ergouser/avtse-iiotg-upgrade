# Sensor Plugin Templates

Use this sensor plugin template to generate a IoTConnect Cloud sensor.  Simply fill out the IoTConnectSDK.conf file with needed needed information. Then write your Python Code in __init__.py.

Once complete copy files to SDK root in a unique IoTPluginXXX directory.


## Versioning

This is version 1.0 of the Sensor Plugin template

## License

This project is licensed under the SmartEdge IIOT Gateway license.

