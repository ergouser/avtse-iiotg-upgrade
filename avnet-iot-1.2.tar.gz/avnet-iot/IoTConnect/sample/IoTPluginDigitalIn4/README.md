# Avnet Smartedge Gateway DigitalIn4

Report Gateway DigitalIn4

## Installation

Selected with IoTConnectSDKConfigure tool

## Versioning

This is version 1.0 of the Avnet Smartedge Gateway DigitalIn4 Plugin.

## License

This project is licensed under the SmartEdge IIOT Gateway license.


