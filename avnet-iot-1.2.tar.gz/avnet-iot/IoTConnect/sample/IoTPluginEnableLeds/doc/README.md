# masterlist.json

This file contains entries that reference github links and is downloaded and used by IoTConnectSDKConfigure


## Versioning

This is version 1.0 of masterlist.json.

## License

This project is licensed under the SmartEdge IIOT Gateway license.
