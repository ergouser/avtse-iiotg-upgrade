# Command Plugin Templates

Use this command plugin template to generate a IoTConnect Cloud command.  Simply fill out the IoTConnectSDK.conf file with needed needed information. Then write your Python Code in __init__.py.

Once complete copy files to SDK root in a unique IoTPluginXXX directory.


## Versioning

This is version 1.0 of the command plugin template

## License

This project is licensed under the SmartEdge IIOT Gateway license.
