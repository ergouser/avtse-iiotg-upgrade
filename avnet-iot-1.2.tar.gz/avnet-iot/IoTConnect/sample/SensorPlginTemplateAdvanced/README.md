# Sensor Advanced Plugin Templates

Use this sensor advanced plugin template to generate a IoTConnect Cloud sensor.  Simply fill out the IoTConnectSDK.conf file with needed needed information. Then write your Python Code in __init__.py.  This feature allows programmable cloud attribute, command and rules advanced features.  This is espcially usefull for plug and play devices, or when you don't know the name/features of a sensor.  This information can be specfied with this example.

Once complete copy files to SDK root in a unique IoTPluginXXX directory.


## Versioning

This is version 1.0 of the Sensor Advanced Plugin template

## License

This project is licensed under the SmartEdge IIOT Gateway license.
