#import pycurl
from io import BytesIO
import py_compile
import threading
import traceback
import sys
import os
import json
import re
import time
import configparser
import subprocess
from subprocess import PIPE, Popen
from collections import defaultdict
from datetime import datetime
my_configs_dict = {}
component_selected_dict = {}
def cmdline(command):
    process = Popen(
        args=command,
        stdout=PIPE,
        shell=True
    )
    return process.communicate()[0]

def main(argv):
    try:
        print("\n\n\n\n        Avnet IoTConnectSDK Configuration Utility\n")
        print("                  Component Selector\n\n")
        #line = raw_input("\nEnter 1 for component selector or 2 for component configuration: ")
        #line = line.rstrip()
        line = '2'
        if (line == '1'):
            #enter Github auth token
            os.system("stty -echo")
            line = raw_input("\nEnter Personal Auth Token: ")
            line = line.rstrip()
            token = line
            os.system("stty echo")
            # get master list from url
            url = 'https://api.github.com/repos/Avnet/PythonSDKPlugins/contents/masterlist.json'
            b_obj = BytesIO()
            crl = pycurl.Curl()
            header = []
            header.append('Authorization: token %s' % token)
            header.append('Accept: application/vnd.github.v3.raw')
            crl.setopt(crl.HTTPHEADER, header)

            #crl.setopt(crl.USERPWD, '%s:%s' %(username, password))
            crl.setopt(crl.URL, str(url))
            #print(str(crl.getopt(crl.HTTPHEADER)))
            crl.setopt(crl.WRITEDATA, b_obj)
            crl.perform() 
            crl.close()
            get_body = b_obj.getvalue()
            f = open('masterlist.json', "w")
            f.write(get_body)
            f.close()
            with open('masterlist.json') as json_file:
                data = json.load(json_file)
            for item in data:
                for item1 in data[item]:
                    for item2 in item1:
                        nextcategory = 0
                        #category_selected_dict = {}
                        category_installed_dict = {}
                        while (nextcategory == 0):
                            category_dict = {}
                            print("\nCategory: " + str(item2))
                            count = 1
                            for item3 in item1[item2]:
                                for item4 in item3:
                                    category_dict[count] = item3[item4]
                                    #category_selected_dict[count] = " "
                                    if (category_installed_dict.has_key(count)):
                                        print("*" + str(count) +"\tDescription: " + str(item3[item4]['description']))
                                    else:
                                        print(" " + str(count) +"\tDescription: " + str(item3[item4]['description']))
                                    
                                    count = count + 1
                            valid = 0
                            while (valid == 0):
                                line = raw_input("\nEnter choice or Next: ")
                                line = line.rstrip()
                                if (line == 'Next') or (line == None):
                                    valid = 1
                                    nextcategory = 1
                                    break
                                line = int(line)
                                category_count = len(category_dict)
                                if ((category_count >= line) and (line > 0)):
                                    valid = 1
                                    #print("Selection valid")
                                else:
                                    print("Invalid selection")
                                    valid = 0
                                    #print(str(category_dict[int(line)]))    
                                if (nextcategory == 0):
                                    category_installed_dict[line] = "*"
                                    #for file1 in category_dict[line]:
                                
                                for file in category_dict[line]['files']:
                                    #print(str(file))
                                    name = file['file']
                                    url = file['download']
                                    #print(url)
                                    to = file['To']
                                    if (str(to) != "./"):
                                        command = "sudo mkdir %s" % to
                                        if (os.path.exists(to) == False):
                                            os.system(command)
                                    b_obj = BytesIO()
                                    

                                    crl = pycurl.Curl()
                                    header = []
                                    header.append('Authorization: token %s' % token)
                                    header.append('Accept: application/vnd.github.v3.raw')
                                    crl.setopt(crl.HTTPHEADER, header)

                                    #crl.setopt(crl.USERPWD, '%s:%s' %(username, password))
                                    crl.setopt(crl.URL, str(url))
                                    crl.setopt(crl.WRITEDATA, b_obj)
                                    crl.perform() 
                                    crl.close()
                                    get_body = b_obj.getvalue()
                                    filename = to + name
                                    f = open(filename, "w")
                                    f.write(get_body)
                                    f.close()
                                    if (file['Compile'] == "Yes"):
                                        # compile then delete code and leave .pyc
                                        py_compile.compile(filename)
                                        os.remove(filename)
                                        filename = filename + 'c'
                                        command = "sudo chmod %d %s" % (int(file['Permissions']) , filename)
                                        os.system(command)
                                    else:
                                        command = "sudo chmod %d %s" % (int(file['Permissions']) , filename)
                                        os.system(command)
                            
                        
                    


        print("\n\n\n\t\t Configure SDK Components\n\n\n")
        component_selected_dict = {}
        
        config = configparser.ConfigParser()
        config.read('IoTConnectSDK.conf.default')
        my_configs_dict = {s:dict(config.items(s)) for s in config.sections()}
        config.read('IoTConnectSDK.conf')
        my_config_parser_current_dict = {s:dict(config.items(s)) for s in config.sections()}
        my_configs_dict.update(my_config_parser_current_dict)
        count = 0
        for item in my_configs_dict:
            #print(item)
            component_selected_dict[count] = [item,'IoTConnectSDK.conf']
            count = count + 1
        count1 = count
        if (int(my_configs_dict["CloudSystemControl"]["systemconfigured"]) == 1):
            line = raw_input("\n\nSystemConfigured Set do you want to clear it Yes/No: ")
            line = line.rstrip()
            if (line == 'Yes'):
                my_configs_dict["CloudSystemControl"]["systemconfigured"] = "0"
        if (int(my_configs_dict["CloudSystemControl"]["systemconfigured"]) == 0):
                    
            #read defaults
            my_configs_dict["CloudSystemControl"]["systemconfigured"] = "1"
            configs = cmdline("find . -name IoTConnectSDK.conf")
            configs = configs.splitlines()
            print("Importing Gateway configuration")
            for item in configs:
                config = configparser.ConfigParser()
                item = item[2:len(item)]
                item = str(item)
                #print(item)
                if (item.find("Plugin") != -1):
                    #print("Importing PluginCfg " + item)
                    config.read(item)
                    #count = count + 1
                    my_config_parser_plugin_dict = {s:dict(config.items(s)) for s in config.sections()}
                    my_configs_dict.update(my_config_parser_plugin_dict)
                    #my_configs_dict = sorted(my_configs_dict)
                    count = 0
                    for item1 in my_configs_dict:
                        #if (count < 2):
                        #    count = count + 1
                        #    continue
                        component_selected_dict[count1] = [item1,item]                   
            count1 = count1 + 1
        #print(my_configs_dict + "\n\n")
        my_configs_desc_dict = {}
        configs_desc = cmdline("find . -name IoTConnectSDK.conf.desc")
        configs_desc = configs_desc.splitlines()
        #print("Importing Gateway configuration")
        for item in configs_desc:
            config = configparser.ConfigParser()
            item = item[2:len(item)]
            item = str(item)
            #print(item)
            if (item.find("Plugin") != -1):
                #print("Importing PluginCfg " + item)
                config.read(item)
                #count = count + 1
                my_config_parser_desc_dict = {s:dict(config.items(s)) for s in config.sections()}
                my_configs_desc_dict.update(my_config_parser_desc_dict)
                #my_configs_dict = sorted(my_configs_dict)
        config.read("IoTConnectSDK.conf.desc")
        my_config_parser_desc_dict = {s:dict(config.items(s)) for s in config.sections()}
        my_configs_desc_dict.update(my_config_parser_desc_dict)
        
        #print(my_configs_desc_dict)
        #my_configs_dict = sorted(my_configs_dict)
        #component_selected_dict = sorted(component_selected_dict)
        #print(str(my_configs_dict) + "\n\n" + str(component_selected_dict))
        while True:
            count = 0
            for item in my_configs_dict:
                #print(component_selected_dict[count])
                print(str(count) + ": " + str(item))
                count = count + 1
                #for line in sys.stdin:
            line = raw_input("\n\nEnter choice or Exit: ")
            line = line.rstrip()
            if (line == 'Exit'):
                break
            #print(component_selected_dict)
            #print("\n\n")
            #print(my_configs_dict)
            print("\n")
            #print(component_selected_dict[int(line)][0])
            this_selection = my_configs_dict[component_selected_dict[int(line)][0]]
            #print("Selection")
            #print(this_selection)
            #print("Selected")
            selected = component_selected_dict[int(line)][0]
            #print(component_selected_dict[int(line)][0])
            #print("\n")
            while True:
                count1 = 0
                for item in my_configs_dict[component_selected_dict[int(line)][0]]:
                    #print(item)
                    if (str(my_configs_desc_dict[str(selected)][item]) != "*"):
                        print(item + "=" + str(this_selection[item]) + "\n\t\tDesc: " + str(my_configs_desc_dict[selected][item]))
                    count1 = count1 + 1
                change = raw_input("Choose item to change. Delete or Back: ")
                found = 0
                if ( 'Back' == change.strip()):
                    print("\033[2J\033[H")
                    break
                if ( 'Delete' == change.strip()):
                    my_configs_dict.pop(component_selected_dict[int(line)][0])
                    count = 0
                    for item in my_configs_dict:
                        #print(item)
                        component_selected_dict[count] = [item, 'unknown']
                        count = count + 1
                    break
                for item in my_configs_dict[component_selected_dict[int(line)][0]]:
                    if (item == change):
                        found = 1
                    if (found == 1):
                        value = raw_input("Enter new value for " + change + " " + this_selection[change] + " : ")
                               
                        this_selection[item] = value
                        my_configs_dict[component_selected_dict[int(line)][0]][change] = value
                        print("Item changed: "+ item + " "+ value)
                        break
        print("Writing Configurations")
        #for item in component_selected_dict:
        #    section = component_selected_dict[item][0]
        #    filename = component_selected_dict[item][1]
        #    print("Section: " + str(section))
        #    print("Filename: " + str(filename))
        parser = configparser.ConfigParser()        
        for item in my_configs_dict:
            parser.add_section(str(item))
            for item1 in my_configs_dict[item]:
                parser.set(item, item1, my_configs_dict[item][item1])
        with open('IoTConnectSDK.conf', 'w') as f:
            parser.write(f)
            
        print("Done.")
        print("Copy the files in this directory to your gateway /opt/avnet-iot/IoTConnect/sample")
    except Exception as ex:
        exc_type, exc_value, exc_traceback = sys.exc_info()
        traceback.print_tb(exc_traceback)
        print(ex)
 
if __name__ == "__main__":
    main(sys.argv)
