# Smartedge Reboot

This command reboots the Smartedge Gateway


## Versioning

This is version 1.0 of the Python Plugin for Reboot

## License

This project is licensed under the SmartEdge IIOT Gateway license.


