# Omega ZW-REC


Please see documentation here.

https://www.newark.com/omega/zw-rec/wireless-receiver-2-4ghz-wall/dp/33AC6944

## Installation

XW Series (XW-ED): Up to 128 End Devices
ZW Series (ZW-ED): Up to 128 End Devices
UW Series (UWTC, UWRTD, UWIR, UWRH, UWPH): Up to 127 End Devices

Please see documentation here.

http://www.farnell.com/datasheets/2363302.pdf

https://www.omega.com/en-us/control-and-monitoring-devices/wireless-monitoring-devices/wireless-transmitters/p/ZW-ED-Series


## Versioning

This is version 1.0 of the ZF Engineering GS100102 Plugin.

## License

This project is licensed under the SmartEdge IIOT Gateway license.

