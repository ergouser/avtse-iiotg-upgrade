# Smartedge Set Digital Output 3

This command sets the Smartedge digital output 3


## Versioning

This is version 1.0 of the Python Plugin for DigitalOutSet3

## License

This project is licensed under the SmartEdge IIOT Gateway license.

