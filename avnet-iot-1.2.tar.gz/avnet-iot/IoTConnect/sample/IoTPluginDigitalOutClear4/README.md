# Smartedge Clear Digital Output 4

This command clears the Smartedge digital output 4


## Versioning

This is version 1.0 of the Python Plugin for DigitalOutClear4

## License

This project is licensed under the SmartEdge IIOT Gateway license.

