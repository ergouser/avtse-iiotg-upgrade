# Smartedge Set Digital Output 1

This command sets the Smartedge digital output 1


## Versioning

This is version 1.0 of the Python Plugin for DigitalOutSet1

## License

This project is licensed under the SmartEdge IIOT Gateway license.

