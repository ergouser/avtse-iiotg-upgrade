# Avnet Smartedge Gateway DigitalIn2

Report Gateway DigitalIn2

## Installation

Selected with IoTConnectSDKConfigure tool

## Versioning

This is version 1.0 of the Avnet Smartedge Gateway DigitalIn2 Plugin.

## License

This project is licensed under the SmartEdge IIOT Gateway license.

