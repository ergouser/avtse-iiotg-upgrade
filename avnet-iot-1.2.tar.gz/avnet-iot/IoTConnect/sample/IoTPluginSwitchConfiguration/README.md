# Smartedge Switch Configuration

This command switches the gateway into AP mode suitable for mobile app configuration.


## Versioning

This is version 1.0 of the Python Plugin for SwitchConfiguration

## License

This project is licensed under the SmartEdge IIOT Gateway license.




## Versioning

This is version 1.0 of masterlist.json.

## License

This project is licensed under the SmartEdge IIOT Gateway license.
