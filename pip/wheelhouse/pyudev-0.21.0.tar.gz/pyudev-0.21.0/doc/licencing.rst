Licencing
=========

.. literalinclude:: ../COPYING
