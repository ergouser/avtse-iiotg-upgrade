import sys
import os
import json
import threading
import datetime
from iotconnect.IoTConnectSDKException import IoTConnectSDKException


class offlineclient:
    _data_path = ""
    _add_sensor_data_path = ""
    _sdk_config = None
    _lock = False
    _thread = None

    def Send(self, data):
        _data = json.dumps(data) + "\n"
        chcekFilePath = self.check_file_size_and_create_new()    
        if chcekFilePath:
            try:
                with open(self._add_sensor_data_path, "a+") as dfile:
                    dfile.write(_data)
            except:
                return False
        return True

    def data_exist1(self):
        try:
            return os.path.exists(self._data_path) == True and os.stat(self._data_path).st_size != 0
        except Exception as ex:
            return False
    
    def data_exist(self):
        try:
            files = os.listdir(sys.path[0] + '/log')
            if len(files) == 0:
                return False
            else:
                return True
            
        except Exception as ex:
            return False

    def divide_chunks(self, l, n):
        # looping till length l
        for i in range(0, len(l), n):
            yield l[i:i + n]

    def read_chunks(self, chunk):
        rows = []
        for obj in chunk:
            try:
                if len(obj) > 0:
                    rows.append(json.loads(obj))
            except:
                print("Faulty data : " + obj)
        return rows

    def send_back_to_client(self):
        try:
            files = os.listdir(sys.path[0] + '/log')
            fileList = []
            fileListDeepCopy = []
            
            for file in files:
                splitFile = file.split('.')
                fileList.append(splitFile[0])
                fileListDeepCopy.append(splitFile[0])
                
            for dataFile in fileList:
                findOldDateTimeFile = min(fileListDeepCopy)
                fileName = findOldDateTimeFile +'.txt'
                self._data_path = os.path.join(sys.path[0]+'/log', fileName)
                
                _data = None
                try:
                    with open(self._data_path, "r") as dfile:
                        _data = dfile.read()
                except:
                    _data = None

                if _data == None:
                    self._thread = None

                with open(self._data_path, "w") as dfile:
                    dfile.write("")

                if _data != None:
                    _data = _data.split("\n")
                
                chunks = list(self.divide_chunks(_data, 10))
                _rData = []
                if len(chunks) > 0:
                    for chunk in chunks:
                        rows = self.read_chunks(chunk)
                        if len(rows) > 0:
                            for row in rows:
                                if self.sendBackToClient(row) == False:
                                    _rData.append(row)

                _fData = ""
                _list = []
                if len(_rData) > 0:
                    for obj in _rData:
                        _list.append(json.dumps(obj))
                    _fData = "\n".join(_list)
                with open(self._add_sensor_data_path, "a") as dfile:
                    dfile.write(_fData)
                fileListDeepCopy.remove(findOldDateTimeFile)
                os.remove(self._data_path)

            self._thread = None
        except Exception as ex:
            print("send_back_to_client : " + ex.message)
            self._thread = None
    
    def PublishData(self):
        try:
            if self._thread == None and self.data_exist():
                self.event_call("PUBDATA", "send_back_to_client",())
        except Exception as ex:
            print("PublishData : ", ex.message)
    
    def event_call(self, name, taget, arg):
        try:
            self._thread = threading.Thread(target=getattr(self, taget), args=arg)
            self._thread.daemon = True
            self._thread.setName(name)
            self._thread.start()
        except Exception as ex:
            print("event_call : " + ex.message)
            
    def sensor_data_add_in_file(self, fileName):
        self._add_sensor_data_path = os.path.join(sys.path[0]+'/log', fileName)
        open(self._add_sensor_data_path, "a+")
        
    def check_file_exist_else_create_new(self):
        files = os.listdir(sys.path[0] + '/log')
            
        fileList = []
        for file in files:
            splitFile = file.split('.')
            fileList.append(splitFile[0])
        
        if len(fileList) == 0:
            fileName = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")+'.txt'
        else:
            findLastDateTimeFile = max(fileList)
            fileName = findLastDateTimeFile +'.txt'
        
        self.sensor_data_add_in_file(fileName)
        
            
    def check_file_size_and_create_new(self):
        try:
            if os.path.exists(self._add_sensor_data_path):
                fileSize = os.stat(self._add_sensor_data_path).st_size
                if fileSize >= 502:
                    fileName = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")+'.txt'
                    self.sensor_data_add_in_file(fileName)

                return True
            else:
                self.sensor_data_add_in_file(self._add_sensor_data_path)
                return True
                
        except Exception as ex:
            return False
        
    def convert_bytes(self, num):
        for x in ['bytes', 'KB', 'MB', 'GB', 'TB']:
            if num < 1024.0:
                return "%3.1f %s" % (num, x)
            num /= 1024.0
    
    def __init__(self, sdk_config, sendBackToClient):
        try:
            self._sdk_config = sdk_config
            
            if self._sdk_config == None:
                raise Exception("SDK Configration not found!")
            
            if not os.path.exists(sys.path[0] + '/log'):
                os.makedirs(sys.path[0] + '/log')
                
            self.check_file_exist_else_create_new()

            self.sendBackToClient = sendBackToClient
        except Exception as ex:
            print("Offline Client Init : " + ex.message)
