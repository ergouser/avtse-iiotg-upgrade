import sys

ERROR_CODE = {
    "01" : "Config file not found.",
    "02" : "Config settings not found.",
    "03" : "CPID not found.",
    "04" : "Unique Id not found.",
    "05" : "Unable to read base URL.",
    "06" : "Sync response not found.",
    "07" : "Sync response # ",
    "08" : "Unable to proceed without info #",
    "09" : "Properties file not found.",
    "10" : "Certificate info not found.",
    "11" : "Invalid file path, please check 'properties.json' file.",
    "12" : "Protocol initialization failed # ",
    "13" : "Template initialization failed for #",
    "14" : "Tumbling window initialization failed for attribute #",
    "15" : "Data processing falied.",
    "16" : "Scope Id not found.",
    "17" : "TPM not found.",
    "18" : "Device registration failed.",
    "19" : "Register device callback # ",
    "20" : "Register status callback # "
}

class IoTConnectSDKException(Exception):
    def __init__(self, code, message = ""):
        if code in ERROR_CODE:
            self.message  = "\nSDK ERR[%s]: %s" % (code, ERROR_CODE[code]) + message
        else:
            if message == "":
                self.message  = "\nERR[00] : Internal Error"
            else:
                self.message  = "\nERR[00] : Internal Error # " + message
