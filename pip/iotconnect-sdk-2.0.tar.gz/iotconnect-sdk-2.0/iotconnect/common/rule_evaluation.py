import sys
import copy
import threading
import time
from datetime import datetime

class rule_evaluation:
    _thread = None
    _command_sender = None
    
    def replace_conditional_operator(self, condition):
        try:
            condition = condition.replace(" = ", " == ")
            condition = condition.replace("AND", "and")
            condition = condition.replace("OR", "or")
            return condition
        except Exception as ex:
            return condition
            print("replace_operator : " + ex.message)
    
    def eval_exp(self,exp):
        try:
            return eval(exp)
        except Exception as ex:
            return False
    
    def evalRules(self, rule, rule_data):
        try:
            if rule == None:
                return
            
            attributeguids = []
            if self.has_key(rule, "att") and rule["att"] != None:
                for attributeguid in rule["att"]:
                    if self.has_key(attributeguid, "g") and attributeguid["g"] != None:
                        if type(attributeguid["g"]) == type(list()):
                            for attributeguid in attributeguid["g"]:
                                attributeguids.append(attributeguid)
                        else:
                            attributeguids.append(attributeguid["g"])
            
            condition = ""
            if self.has_key(rule, "con") and rule["con"] != None:
                condition = self.replace_conditional_operator(str(rule["con"]))
            
            command_text = ""
            if self.has_key(rule, "cmd") and rule["cmd"] != None:
                command_text = str(rule["cmd"])
            
            if len(attributeguids) > 0 and condition != "":
                for rdata in rule_data:
                    rdata["valid"] = []
                    for data in rdata["d"]:
                        if rdata["p"] == "":
                            prop = data["ln"]
                        else:
                            prop = rdata["p"] + "." + data["ln"]
                        
                        condition = condition.replace(prop, str(data["v"]))
                        for attrguid in attributeguids:
                            if self.has_key(data, "g") and attrguid == data["g"]:
                                rdata["valid"].append(data)
                
                if self.eval_exp(condition) == True:
                    print("\n---- Rule Matched ---")
                    if self._command_sender and command_text != "":
                        self._command_sender(command_text)
                    
                    sdata = []
                    for rdata in rule_data:
                        if len(rdata["valid"]) > 0:
                            data = copy.deepcopy(rdata)
                            data["st"] = self._timestamp
                            data["d"] = rdata["valid"]
                            del data["valid"]
                            sdata.append(data)
                    
                    if len(sdata) > 0:
                        self.event_call("send_rule_data", [sdata, rule])
                else:
                    print("\n---- Rule Not Matched ---")
        except Exception as ex:
            print("evalRules : " + ex.message)
    
    def send_rule_data(self, data, rule):
        try:
            if self.listner_callback != None:
                self.listner_callback(data, rule)
            
            if self._thread != None:
                self._thread = None
        except Exception as ex:
            print("send_rule_data : " + ex.message)
    
    def event_call(self, taget, arg):
        if self._thread != None:
            self._thread = None
        
        self._thread = threading.Thread(target= getattr(self, taget),args=arg)
        self._thread.daemon = True
        self._thread.setName("SRD")
        self._thread.start()
    
    def has_key(self, data, key):
        try:
            return key in data
        except Exception as ex:
            return False
    
    @property
    def _timestamp(self):
        return datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S.000Z")
    
    def __init__(self, listner, command_sender):
        if listner != None:
            self.listner_callback = listner
        
        if command_sender != None:
            self._command_sender = command_sender

