import os
import sys
from setuptools import setup

setup(
    name="iotconnect-sdk",
    version="2.0",
    python_requires='>=2.7,<3.7',
    description='SDK for D2C and C2D communication',
    license="MIT",
    author='SOFTWEB SOLUTIONS<admin@softwebsolutions.com> (https://www.softwebsolutions.com)',
    packages=["iotconnect", "iotconnect.client", "iotconnect.common"],
    install_requires=["paho-mqtt","wheel","azure-iot-provisioning-device-client","azure-iothub-device-client"],
    package_data={'iotconnect': ['assets/*.*']},
    platforms=['Linux', 'Mac OS X', 'Win'],
    zip_safe=False,
    classifiers=[
        "Programming Language :: Python :: 2.7",
        "Programming Language :: Python :: 3.6",
        "License :: MIT License",
        "Operating System :: OS Independent"
    ],
)