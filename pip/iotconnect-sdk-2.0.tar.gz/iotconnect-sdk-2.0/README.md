# Softweb Solutions Inc
## IOT Connect SDK : Software Development Kit 1.0.0

**Prerequisite tools:**

1. Python : Python version 2.7, 3.6 and 3.7
2. pip : pip is compatible to the python version
3. setuptools : Required to install IOTConnect SDK

**Installation for python vesion 2.7:**

1. Extract the "iotconnect-sdk-python-v1.0.0.zip"

2. To install the required libraries use the below command:
	- Goto SDK directory path using terminal/Command prompt
	- cd iotconnect-sdk/
    - pip install iotconnect-sdk-2.0.tar.gz

3. Using terminal/command prompt goto sample folder
	- cd iotconnect-sdk/sample 

4. Ready to go: //This script can send the data to given input(uniqueid, cpid) device by command prompt
    - python example_py2.py <<env>> //Environment DEV, QA, POC, AVNETPOC, PROD (Default if not supply the environment argument)

**Usage :**

Import library
```python
from iotconnect import IoTConnectSDK
```

Prerequisite input data *
```python
uniqueId = <<uniqueId>>
cpid = <<CPID>> 
env = <<env>> // DEV, QA, POC, AVNETPOC, PROD(Default)
```

To get the device information and connect to the device
```python
with IoTConnectSDK(cpid, uniqueId, callbackMessage, callbackTwinMessage, env) as sdk:
```

To receive the command from Cloud to Device(C2D) 
```python
def callbackMessage(msg):
    print(msg)
```

To receive the twin from Cloud to Device(C2D) 
```python
def callbackTwinMessage(msg):
    print(msg)
```

To get the list of attributes
```python
sdk.GetAttributes()
```

Data input format
```python
sendTeledata = [{
    "uniqueId": "123456",
    "time" : '2018-05-24T10:06:17.857Z', //Date format should be as defined
    "data": {
        "temperature": 15.55,
        "humidity" : 27.97,
        "weight" : 36,
        "gyroscope" : {
            'x' : -1.2,
            'y' : 0.25,
            'z' : 1.1,
        }
    }
}]
```

To send the data from Device To Cloud(D2C)
```python
sdk.SendData(sendTeledata)
```

To update the Twin Property

```python
key = "firmware_version"
value = "4.0"

sdk.UpdateTwin(key, value)
```

- To configure the secure SSL/x509 connection follow below step for CA or CA Selfsiged certificate
	- Open file : sample/properties.json
    - Set SSL/x509 certificate path for CA sign and Selfsign certificate like as below

```json
{
	"certificate" : { 
		"SSLKeyPath"	: "<< file path >>/key.pem",
		"SSLCertPath"   : "<< file path >>/cert.pem",
		"SSLCaPath"     : "<< file path >>/ca.cert.pem"
	}
}
```
